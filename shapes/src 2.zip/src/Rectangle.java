public class Rectangle {
	private double length;
	public void setLength(double i) {
		this.length = i;
		//initialize length or create variable
	}
	public double getLength() {
		return length;
	}
	private double height;
	public void setHeight(double i) {
		this.height = i;
	}
	public double getHeight() {
		return height;
	}
	public Rectangle(){
		setLength(0);
		setHeight(0);
		//calling length and height
	}
	public Rectangle(double length, double height) {
		setLength(length);
		setHeight(height);
	}
	public double area() {
		return getLength() * getHeight();
		//formula for area of a rectangle is length times height
	}
	public String toString() {
		return "The area of the rectangle is: "+ this.area();	
		//print the result 
	}
	public boolean equals(Rectangle input) {
		return area() == input.area();
	}
}

