//lily deller
public class Circle {
	private double radius;
	//making variables
	public void setRadius(double i) {	
		this.radius = i;
	}
	public Circle(){
		setRadius(0);
		//calling radius
	}
	public Circle(double i) {	
		setRadius(i);
	}
	public double getRadius() {
		return radius;
	}
	public double area() {
		return Math.PI * getRadius() * getRadius();
		//formula for area of circle is pi r^2
		//using the Math.PI method
	}
	public String toString() {
		return "The area of the circle is: "+ this.area();		
	}
	public boolean equals(Circle input) {
		return area()== input.area();
	}
}
